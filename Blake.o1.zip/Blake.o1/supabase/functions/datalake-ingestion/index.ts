import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { corsHeaders } from '../_shared/cors.ts'

interface IngestionConfig {
  source: string;
  type: string;
  category: string;
  frequency: string;
  params: Record<string, any>;
}

serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { config } = await req.json()
    const ingestionConfig = config as IngestionConfig

    // Récupération des données depuis la source
    const sourceData = await fetchSourceData(ingestionConfig)

    // Validation et nettoyage des données
    const validatedData = validateData(sourceData, ingestionConfig)

    // Stockage dans le Datalake
    const { data, error } = await storeData(validatedData, ingestionConfig, supabase)
    if (error) throw error

    return new Response(
      JSON.stringify({ success: true, data }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      }
    )
  }
})

async function fetchSourceData(config: IngestionConfig) {
  switch (config.source) {
    case 'alpha-vantage':
      return await fetchAlphaVantageData(config.params)
    case 'fred':
      return await fetchFREDData(config.params)
    case 'fmp':
      return await fetchFMPData(config.params)
    default:
      throw new Error(`Source non supportée: ${config.source}`)
  }
}

function validateData(data: any, config: IngestionConfig) {
  // Validation du format des données
  if (!Array.isArray(data)) {
    throw new Error('Les données doivent être un tableau')
  }

  // Validation des champs requis
  const validatedData = data.map(item => {
    if (!item.timestamp) {
      throw new Error('Chaque élément doit avoir un timestamp')
    }
    return {
      ...item,
      timestamp: new Date(item.timestamp).toISOString()
    }
  })

  return validatedData
}

async function storeData(data: any[], config: IngestionConfig, supabase: any) {
  // Création ou mise à jour de l'élément dans datalake_items
  const { data: item, error: itemError } = await supabase
    .from('datalake_items')
    .upsert({
      type: config.type,
      category: config.category,
      title: config.params.title,
      description: config.params.description,
      source: config.source,
      metadata: {
        frequency: config.frequency,
        source_params: config.params,
        last_ingestion: new Date().toISOString()
      }
    })
    .select()
    .single()

  if (itemError) throw itemError

  // Stockage des données temporelles
  const { error: timeseriesError } = await supabase
    .from('datalake_timeseries')
    .insert(
      data.map(point => ({
        item_id: item.id,
        timestamp: point.timestamp,
        value: point.value,
        metadata: point.metadata || {}
      }))
    )

  if (timeseriesError) throw timeseriesError

  return { data: item, error: null }
}

// Fonctions de récupération des données
async function fetchAlphaVantageData(params: any) {
  // Implémentation de la récupération depuis Alpha Vantage
  return []
}

async function fetchFREDData(params: any) {
  // Implémentation de la récupération depuis FRED
  return []
}

async function fetchFMPData(params: any) {
  // Implémentation de la récupération depuis Financial Modeling Prep
  return []
} 
import { TimeSeriesPoint } from './transformations.ts'

// Moyennes mobiles
export function calculateSMA(data: TimeSeriesPoint[], window: number): TimeSeriesPoint[] {
  const result: TimeSeriesPoint[] = []
  const values = data.map(p => p.value)

  for (let i = window - 1; i < values.length; i++) {
    const windowSlice = values.slice(i - window + 1, i + 1)
    const average = windowSlice.reduce((a, b) => a + b, 0) / window

    result.push({
      timestamp: data[i].timestamp,
      value: average,
      metadata: {
        indicator: 'SMA',
        window,
        original_value: data[i].value
      }
    })
  }

  return result
}

export function calculateEMA(data: TimeSeriesPoint[], window: number): TimeSeriesPoint[] {
  const result: TimeSeriesPoint[] = []
  const values = data.map(p => p.value)
  const multiplier = 2 / (window + 1)

  let ema = values.slice(0, window).reduce((a, b) => a + b, 0) / window
  result.push({
    timestamp: data[window - 1].timestamp,
    value: ema,
    metadata: {
      indicator: 'EMA',
      window,
      original_value: data[window - 1].value
    }
  })

  for (let i = window; i < values.length; i++) {
    ema = (values[i] - ema) * multiplier + ema
    result.push({
      timestamp: data[i].timestamp,
      value: ema,
      metadata: {
        indicator: 'EMA',
        window,
        original_value: data[i].value
      }
    })
  }

  return result
}

// RSI (Relative Strength Index)
export function calculateRSI(data: TimeSeriesPoint[], window: number): TimeSeriesPoint[] {
  const result: TimeSeriesPoint[] = []
  const values = data.map(p => p.value)
  const changes = []

  for (let i = 1; i < values.length; i++) {
    changes.push(values[i] - values[i - 1])
  }

  let avgGain = changes.slice(0, window)
    .filter(change => change > 0)
    .reduce((a, b) => a + b, 0) / window

  let avgLoss = Math.abs(
    changes.slice(0, window)
      .filter(change => change < 0)
      .reduce((a, b) => a + b, 0) / window
  )

  const calculateRS = (gain: number, loss: number) => 
    loss === 0 ? 100 : gain === 0 ? 0 : 100 - (100 / (1 + gain / loss))

  result.push({
    timestamp: data[window].timestamp,
    value: calculateRS(avgGain, avgLoss),
    metadata: {
      indicator: 'RSI',
      window,
      avgGain,
      avgLoss
    }
  })

  for (let i = window + 1; i < values.length; i++) {
    const change = changes[i - 1]
    const gain = change > 0 ? change : 0
    const loss = change < 0 ? Math.abs(change) : 0

    avgGain = ((avgGain * (window - 1)) + gain) / window
    avgLoss = ((avgLoss * (window - 1)) + loss) / window

    result.push({
      timestamp: data[i].timestamp,
      value: calculateRS(avgGain, avgLoss),
      metadata: {
        indicator: 'RSI',
        window,
        avgGain,
        avgLoss
      }
    })
  }

  return result
}

// Bandes de Bollinger
export function calculateBollingerBands(
  data: TimeSeriesPoint[], 
  window: number = 20, 
  stdDev: number = 2
): Record<string, TimeSeriesPoint[]> {
  const middle = calculateSMA(data, window)
  const values = data.map(p => p.value)
  const upper: TimeSeriesPoint[] = []
  const lower: TimeSeriesPoint[] = []

  for (let i = window - 1; i < values.length; i++) {
    const windowSlice = values.slice(i - window + 1, i + 1)
    const avg = middle[i - (window - 1)].value
    const std = Math.sqrt(
      windowSlice.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / window
    )

    const upperBand = avg + (stdDev * std)
    const lowerBand = avg - (stdDev * std)

    upper.push({
      timestamp: data[i].timestamp,
      value: upperBand,
      metadata: {
        indicator: 'BB_UPPER',
        window,
        stdDev,
        middle: avg
      }
    })

    lower.push({
      timestamp: data[i].timestamp,
      value: lowerBand,
      metadata: {
        indicator: 'BB_LOWER',
        window,
        stdDev,
        middle: avg
      }
    })
  }

  return {
    middle,
    upper,
    lower
  }
}

// MACD (Moving Average Convergence Divergence)
export function calculateMACD(
  data: TimeSeriesPoint[],
  fastPeriod: number = 12,
  slowPeriod: number = 26,
  signalPeriod: number = 9
): Record<string, TimeSeriesPoint[]> {
  const fastEMA = calculateEMA(data, fastPeriod)
  const slowEMA = calculateEMA(data, slowPeriod)
  const macdLine: TimeSeriesPoint[] = []
  const signalLine: TimeSeriesPoint[] = []
  const histogram: TimeSeriesPoint[] = []

  // Calculer la ligne MACD
  for (let i = slowPeriod - 1; i < data.length; i++) {
    const macdValue = fastEMA[i - (slowPeriod - fastPeriod)].value - slowEMA[i - (slowPeriod - 1)].value
    macdLine.push({
      timestamp: data[i].timestamp,
      value: macdValue,
      metadata: {
        indicator: 'MACD_LINE',
        fastPeriod,
        slowPeriod
      }
    })
  }

  // Calculer la ligne de signal (EMA de la ligne MACD)
  const signalEMA = calculateEMA(macdLine, signalPeriod)

  // Calculer l'histogramme
  for (let i = 0; i < signalEMA.length; i++) {
    const histValue = macdLine[i + signalPeriod - 1].value - signalEMA[i].value
    histogram.push({
      timestamp: data[i + slowPeriod + signalPeriod - 2].timestamp,
      value: histValue,
      metadata: {
        indicator: 'MACD_HIST',
        fastPeriod,
        slowPeriod,
        signalPeriod
      }
    })
  }

  return {
    macd: macdLine,
    signal: signalEMA,
    histogram
  }
}

// Momentum
export function calculateMomentum(data: TimeSeriesPoint[], period: number): TimeSeriesPoint[] {
  const result: TimeSeriesPoint[] = []
  const values = data.map(p => p.value)

  for (let i = period; i < values.length; i++) {
    const momentum = values[i] - values[i - period]
    result.push({
      timestamp: data[i].timestamp,
      value: momentum,
      metadata: {
        indicator: 'MOMENTUM',
        period,
        reference_value: values[i - period]
      }
    })
  }

  return result
} 
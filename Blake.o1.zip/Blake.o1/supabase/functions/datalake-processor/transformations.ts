import { parse } from 'https://deno.land/std@0.168.0/datetime/mod.ts'

interface TimeSeriesPoint {
  timestamp: string;
  value: number;
  metadata?: Record<string, any>;
}

// Fonction de resampling des séries temporelles
export function resampleTimeSeries(
  data: TimeSeriesPoint[],
  params: { frequency: string; method: 'mean' | 'sum' | 'first' | 'last' }
): TimeSeriesPoint[] {
  const { frequency, method = 'mean' } = params
  const sortedData = [...data].sort((a, b) => 
    new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  )

  // Grouper les données par période
  const groups = new Map<string, TimeSeriesPoint[]>()
  
  sortedData.forEach(point => {
    const date = new Date(point.timestamp)
    const key = getTimeKey(date, frequency)
    if (!groups.has(key)) {
      groups.set(key, [])
    }
    groups.get(key)?.push(point)
  })

  // Agréger chaque groupe selon la méthode choisie
  return Array.from(groups.entries()).map(([key, points]) => ({
    timestamp: key,
    value: aggregateValues(points.map(p => p.value), method),
    metadata: {
      aggregation_method: method,
      original_points: points.length
    }
  }))
}

// Fonction de normalisation des données
export function normalizeData(
  data: TimeSeriesPoint[],
  params: { method: 'zscore' | 'minmax' | 'robust' }
): TimeSeriesPoint[] {
  const values = data.map(p => p.value)
  let normalizedValues: number[]

  switch (params.method) {
    case 'zscore':
      normalizedValues = zScoreNormalization(values)
      break
    case 'minmax':
      normalizedValues = minMaxNormalization(values)
      break
    case 'robust':
      normalizedValues = robustNormalization(values)
      break
    default:
      throw new Error(`Méthode de normalisation non supportée: ${params.method}`)
  }

  return data.map((point, index) => ({
    ...point,
    value: normalizedValues[index],
    metadata: {
      ...point.metadata,
      normalization_method: params.method,
      original_value: point.value
    }
  }))
}

// Fonction de remplissage des valeurs manquantes
export function fillMissingValues(
  data: TimeSeriesPoint[],
  params: { 
    method: 'ffill' | 'bfill' | 'interpolate' | 'value',
    value?: number 
  }
): TimeSeriesPoint[] {
  const sortedData = [...data].sort((a, b) => 
    new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  )

  const result: TimeSeriesPoint[] = []
  let lastValue: number | null = null

  for (let i = 0; i < sortedData.length; i++) {
    const point = sortedData[i]
    
    if (isNaN(point.value) || point.value === null) {
      let filledValue: number

      switch (params.method) {
        case 'ffill':
          filledValue = lastValue ?? params.value ?? 0
          break
        case 'bfill':
          filledValue = findNextValue(sortedData, i) ?? params.value ?? 0
          break
        case 'interpolate':
          filledValue = interpolateValue(sortedData, i)
          break
        case 'value':
          filledValue = params.value ?? 0
          break
        default:
          throw new Error(`Méthode de remplissage non supportée: ${params.method}`)
      }

      result.push({
        ...point,
        value: filledValue,
        metadata: {
          ...point.metadata,
          filling_method: params.method,
          is_filled: true,
          original_value: point.value
        }
      })
    } else {
      result.push(point)
      lastValue = point.value
    }
  }

  return result
}

// Fonction de calcul de métriques statistiques
export function calculateMetrics(
  data: TimeSeriesPoint[],
  params: { 
    metrics: Array<'sma' | 'ema' | 'std' | 'rsi' | 'momentum'>,
    window?: number
  }
): Record<string, TimeSeriesPoint[]> {
  const { metrics, window = 14 } = params
  const results: Record<string, TimeSeriesPoint[]> = {}

  metrics.forEach(metric => {
    switch (metric) {
      case 'sma':
        results.sma = calculateSMA(data, window)
        break
      case 'ema':
        results.ema = calculateEMA(data, window)
        break
      case 'std':
        results.std = calculateStandardDeviation(data, window)
        break
      case 'rsi':
        results.rsi = calculateRSI(data, window)
        break
      case 'momentum':
        results.momentum = calculateMomentum(data, window)
        break
    }
  })

  return results
}

// Fonctions utilitaires
function getTimeKey(date: Date, frequency: string): string {
  switch (frequency) {
    case 'hourly':
      return date.toISOString().slice(0, 13) + ':00:00Z'
    case 'daily':
      return date.toISOString().slice(0, 10)
    case 'weekly':
      const weekStart = new Date(date)
      weekStart.setDate(date.getDate() - date.getDay())
      return weekStart.toISOString().slice(0, 10)
    case 'monthly':
      return date.toISOString().slice(0, 7) + '-01'
    default:
      throw new Error(`Fréquence non supportée: ${frequency}`)
  }
}

function aggregateValues(values: number[], method: string): number {
  switch (method) {
    case 'mean':
      return values.reduce((a, b) => a + b, 0) / values.length
    case 'sum':
      return values.reduce((a, b) => a + b, 0)
    case 'first':
      return values[0]
    case 'last':
      return values[values.length - 1]
    default:
      throw new Error(`Méthode d'agrégation non supportée: ${method}`)
  }
}

function zScoreNormalization(values: number[]): number[] {
  const mean = values.reduce((a, b) => a + b, 0) / values.length
  const std = Math.sqrt(
    values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length
  )
  return values.map(v => (v - mean) / std)
}

function minMaxNormalization(values: number[]): number[] {
  const min = Math.min(...values)
  const max = Math.max(...values)
  return values.map(v => (v - min) / (max - min))
}

function robustNormalization(values: number[]): number[] {
  const sorted = [...values].sort((a, b) => a - b)
  const q1 = sorted[Math.floor(sorted.length * 0.25)]
  const q3 = sorted[Math.floor(sorted.length * 0.75)]
  const iqr = q3 - q1
  return values.map(v => (v - q1) / iqr)
}

function findNextValue(data: TimeSeriesPoint[], currentIndex: number): number | null {
  for (let i = currentIndex + 1; i < data.length; i++) {
    if (!isNaN(data[i].value) && data[i].value !== null) {
      return data[i].value
    }
  }
  return null
}

function interpolateValue(data: TimeSeriesPoint[], currentIndex: number): number {
  let prevValue: number | null = null
  let nextValue: number | null = null
  let prevIndex = currentIndex
  let nextIndex = currentIndex

  // Trouver la valeur précédente
  while (prevIndex >= 0) {
    if (!isNaN(data[prevIndex].value) && data[prevIndex].value !== null) {
      prevValue = data[prevIndex].value
      break
    }
    prevIndex--
  }

  // Trouver la valeur suivante
  while (nextIndex < data.length) {
    if (!isNaN(data[nextIndex].value) && data[nextIndex].value !== null) {
      nextValue = data[nextIndex].value
      break
    }
    nextIndex++
  }

  if (prevValue === null || nextValue === null) {
    return prevValue ?? nextValue ?? 0
  }

  // Interpolation linéaire
  const ratio = (currentIndex - prevIndex) / (nextIndex - prevIndex)
  return prevValue + (nextValue - prevValue) * ratio
} 
import { TimeSeriesPoint } from './transformations.ts'
import * as technical from './technical.ts'

interface AnalysisResult {
  timestamp: string;
  signal: 'buy' | 'sell' | 'hold';
  strength: number;
  indicators: Record<string, any>;
  metadata: Record<string, any>;
}

export function analyzeMarketConditions(
  data: TimeSeriesPoint[],
  config: {
    rsiWindow?: number;
    macdConfig?: {
      fastPeriod: number;
      slowPeriod: number;
      signalPeriod: number;
    };
    bollingerWindow?: number;
    momentumPeriod?: number;
  } = {}
): AnalysisResult[] {
  const {
    rsiWindow = 14,
    macdConfig = { fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 },
    bollingerWindow = 20,
    momentumPeriod = 10
  } = config

  // Calculer les indicateurs
  const rsi = technical.calculateRSI(data, rsiWindow)
  const macd = technical.calculateMACD(data, macdConfig.fastPeriod, macdConfig.slowPeriod, macdConfig.signalPeriod)
  const bollinger = technical.calculateBollingerBands(data, bollingerWindow)
  const momentum = technical.calculateMomentum(data, momentumPeriod)

  const results: AnalysisResult[] = []

  // Analyser les signaux pour chaque point de données
  for (let i = 0; i < data.length; i++) {
    if (!rsi[i] || !macd.macd[i] || !bollinger.middle[i] || !momentum[i]) continue

    const signals = []
    let totalStrength = 0

    // Analyse RSI
    if (rsi[i].value < 30) {
      signals.push({ type: 'buy', strength: 0.3 })
    } else if (rsi[i].value > 70) {
      signals.push({ type: 'sell', strength: 0.3 })
    }

    // Analyse MACD
    if (macd.histogram[i]?.value > 0 && macd.histogram[i - 1]?.value <= 0) {
      signals.push({ type: 'buy', strength: 0.25 })
    } else if (macd.histogram[i]?.value < 0 && macd.histogram[i - 1]?.value >= 0) {
      signals.push({ type: 'sell', strength: 0.25 })
    }

    // Analyse Bollinger
    const price = data[i].value
    if (price <= bollinger.lower[i].value) {
      signals.push({ type: 'buy', strength: 0.25 })
    } else if (price >= bollinger.upper[i].value) {
      signals.push({ type: 'sell', strength: 0.25 })
    }

    // Analyse Momentum
    if (momentum[i].value > 0) {
      signals.push({ type: 'buy', strength: 0.2 })
    } else if (momentum[i].value < 0) {
      signals.push({ type: 'sell', strength: 0.2 })
    }

    // Agréger les signaux
    const buyStrength = signals
      .filter(s => s.type === 'buy')
      .reduce((acc, s) => acc + s.strength, 0)
    
    const sellStrength = signals
      .filter(s => s.type === 'sell')
      .reduce((acc, s) => acc + s.strength, 0)

    let finalSignal: 'buy' | 'sell' | 'hold' = 'hold'
    let signalStrength = 0

    if (buyStrength > sellStrength && buyStrength > 0.4) {
      finalSignal = 'buy'
      signalStrength = buyStrength
    } else if (sellStrength > buyStrength && sellStrength > 0.4) {
      finalSignal = 'sell'
      signalStrength = sellStrength
    }

    results.push({
      timestamp: data[i].timestamp,
      signal: finalSignal,
      strength: signalStrength,
      indicators: {
        rsi: rsi[i].value,
        macd: macd.macd[i].value,
        macdSignal: macd.signal[i]?.value,
        macdHist: macd.histogram[i]?.value,
        bollingerUpper: bollinger.upper[i].value,
        bollingerMiddle: bollinger.middle[i].value,
        bollingerLower: bollinger.lower[i].value,
        momentum: momentum[i].value
      },
      metadata: {
        price: data[i].value,
        signals
      }
    })
  }

  return results
} 
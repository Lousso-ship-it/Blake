import { TimeSeriesPoint } from './transformations.ts'
import { analyzeMarketConditions } from './analysis.ts'

interface Position {
  entryPrice: number;
  entryTime: string;
  size: number;
  type: 'long' | 'short';
}

interface Trade {
  entryPrice: number;
  entryTime: string;
  exitPrice: number;
  exitTime: string;
  type: 'long' | 'short';
  size: number;
  pnl: number;
  pnlPercent: number;
  holdingPeriod: number;
}

interface BacktestResult {
  trades: Trade[];
  metrics: {
    totalTrades: number;
    winningTrades: number;
    losingTrades: number;
    winRate: number;
    averageWin: number;
    averageLoss: number;
    largestWin: number;
    largestLoss: number;
    profitFactor: number;
    sharpeRatio: number;
    maxDrawdown: number;
    totalReturn: number;
    annualizedReturn: number;
  };
  equity: TimeSeriesPoint[];
}

export async function runBacktest(
  data: TimeSeriesPoint[],
  config: {
    initialCapital: number;
    positionSize: number;
    stopLoss?: number;
    takeProfit?: number;
    maxPositions?: number;
    analysisConfig?: Record<string, any>;
  }
): Promise<BacktestResult> {
  const {
    initialCapital,
    positionSize,
    stopLoss = 0.02,
    takeProfit = 0.05,
    maxPositions = 1,
    analysisConfig = {}
  } = config

  let capital = initialCapital
  let positions: Position[] = []
  const trades: Trade[] = []
  const equity: TimeSeriesPoint[] = []

  // Analyser les conditions de marché
  const analysis = analyzeMarketConditions(data, analysisConfig)

  // Simuler le trading
  for (let i = 0; i < data.length; i++) {
    const currentPrice = data[i].value
    const currentTime = data[i].timestamp
    const signal = analysis[i]

    // Gérer les positions existantes
    positions = positions.map(position => {
      const pnl = position.type === 'long'
        ? (currentPrice - position.entryPrice) / position.entryPrice
        : (position.entryPrice - currentPrice) / position.entryPrice

      // Vérifier stop loss et take profit
      if (pnl <= -stopLoss || pnl >= takeProfit) {
        trades.push({
          entryPrice: position.entryPrice,
          entryTime: position.entryTime,
          exitPrice: currentPrice,
          exitTime: currentTime,
          type: position.type,
          size: position.size,
          pnl: pnl * position.size,
          pnlPercent: pnl * 100,
          holdingPeriod: i - data.findIndex(d => d.timestamp === position.entryTime)
        })

        capital += position.size * (1 + pnl)
        return null
      }

      return position
    }).filter(Boolean) as Position[]

    // Ouvrir de nouvelles positions
    if (positions.length < maxPositions) {
      if (signal.signal === 'buy' && signal.strength > 0.6) {
        const size = capital * positionSize
        positions.push({
          entryPrice: currentPrice,
          entryTime: currentTime,
          size,
          type: 'long'
        })
        capital -= size
      } else if (signal.signal === 'sell' && signal.strength > 0.6) {
        const size = capital * positionSize
        positions.push({
          entryPrice: currentPrice,
          entryTime: currentTime,
          size,
          type: 'short'
        })
        capital -= size
      }
    }

    // Enregistrer l'équité
    const positionsValue = positions.reduce((acc, pos) => {
      const pnl = pos.type === 'long'
        ? (currentPrice - pos.entryPrice) / pos.entryPrice
        : (pos.entryPrice - currentPrice) / pos.entryPrice
      return acc + (pos.size * (1 + pnl))
    }, 0)

    equity.push({
      timestamp: currentTime,
      value: capital + positionsValue,
      metadata: {
        positions: positions.length,
        capital,
        positionsValue
      }
    })
  }

  // Calculer les métriques
  const metrics = calculateBacktestMetrics(trades, equity, initialCapital)

  return {
    trades,
    metrics,
    equity
  }
}

function calculateBacktestMetrics(
  trades: Trade[],
  equity: TimeSeriesPoint[],
  initialCapital: number
): BacktestResult['metrics'] {
  const winningTrades = trades.filter(t => t.pnl > 0)
  const losingTrades = trades.filter(t => t.pnl < 0)

  const totalReturn = (equity[equity.length - 1].value - initialCapital) / initialCapital
  const returns = equity.map((e, i) => 
    i > 0 ? (e.value - equity[i-1].value) / equity[i-1].value : 0
  )

  return {
    totalTrades: trades.length,
    winningTrades: winningTrades.length,
    losingTrades: losingTrades.length,
    winRate: winningTrades.length / trades.length,
    averageWin: winningTrades.reduce((acc, t) => acc + t.pnlPercent, 0) / winningTrades.length,
    averageLoss: losingTrades.reduce((acc, t) => acc + t.pnlPercent, 0) / losingTrades.length,
    largestWin: Math.max(...trades.map(t => t.pnlPercent)),
    largestLoss: Math.min(...trades.map(t => t.pnlPercent)),
    profitFactor: Math.abs(
      winningTrades.reduce((acc, t) => acc + t.pnl, 0) /
      losingTrades.reduce((acc, t) => acc + t.pnl, 0)
    ),
    sharpeRatio: calculateSharpeRatio(returns),
    maxDrawdown: calculateMaxDrawdown(equity),
    totalReturn: totalReturn * 100,
    annualizedReturn: calculateAnnualizedReturn(totalReturn, equity)
  }
}

function calculateSharpeRatio(returns: number[]): number {
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length
  const std = Math.sqrt(
    returns.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / returns.length
  )
  return (mean * Math.sqrt(252)) / std
}

function calculateMaxDrawdown(equity: TimeSeriesPoint[]): number {
  let maxDrawdown = 0
  let peak = equity[0].value

  for (const point of equity) {
    if (point.value > peak) {
      peak = point.value
    }
    const drawdown = (peak - point.value) / peak
    maxDrawdown = Math.max(maxDrawdown, drawdown)
  }

  return maxDrawdown * 100
}

function calculateAnnualizedReturn(totalReturn: number, equity: TimeSeriesPoint[]): number {
  const years = (
    new Date(equity[equity.length - 1].timestamp).getTime() -
    new Date(equity[0].timestamp).getTime()
  ) / (1000 * 60 * 60 * 24 * 365)

  return (Math.pow(1 + totalReturn, 1 / years) - 1) * 100
} 
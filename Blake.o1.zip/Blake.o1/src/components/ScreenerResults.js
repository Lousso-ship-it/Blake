import React, { useState } from 'react';
import { Line } from 'react-chartjs-2';
import './ScreenerResults.css';

function ScreenerResults({ results }) {
  const [sortConfig, setSortConfig] = useState({
    key: 'marketCap',
    direction: 'desc'
  });

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'desc' ? 'asc' : 'desc'
    }));
  };

  const getSortedResults = () => {
    if (!results) return [];
    
    return [...results].sort((a, b) => {
      if (a[sortConfig.key] < b[sortConfig.key]) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (a[sortConfig.key] > b[sortConfig.key]) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
  };

  const formatNumber = (num, type) => {
    if (type === 'price') return `$${num.toFixed(2)}`;
    if (type === 'volume') return `$${(num/1000000).toFixed(2)}M`;
    if (type === 'marketCap') return `$${(num/1000000000).toFixed(2)}B`;
    if (type === 'percent') return `${num > 0 ? '+' : ''}${num.toFixed(2)}%`;
    return num;
  };

  const renderMiniChart = (data) => {
    const chartData = {
      labels: data.map((_, i) => i),
      datasets: [{
        data: data,
        borderColor: data[data.length - 1] > data[0] ? '#26a69a' : '#ef5350',
        borderWidth: 1.5,
        tension: 0.4,
        pointRadius: 0
      }]
    };

    const options = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { display: false },
        y: { display: false }
      }
    };

    return <Line data={chartData} options={options} />;
  };

  return (
    <div className="screener-results">
      <div className="results-header">
        <div className="results-count">
          {results?.length} actifs trouvés
        </div>
        <div className="view-options">
          <button className="view-btn active">
            <i className="fas fa-table"></i>
          </button>
          <button className="view-btn">
            <i className="fas fa-th-large"></i>
          </button>
        </div>
      </div>

      <div className="results-table">
        <table>
          <thead>
            <tr>
              <th>Symbole</th>
              <th onClick={() => handleSort('price')}>
                Prix
                {sortConfig.key === 'price' && (
                  <i className={`fas fa-sort-${sortConfig.direction === 'asc' ? 'up' : 'down'}`}></i>
                )}
              </th>
              <th onClick={() => handleSort('change24h')}>
                24h %
                {sortConfig.key === 'change24h' && (
                  <i className={`fas fa-sort-${sortConfig.direction === 'asc' ? 'up' : 'down'}`}></i>
                )}
              </th>
              <th onClick={() => handleSort('volume')}>
                Volume
                {sortConfig.key === 'volume' && (
                  <i className={`fas fa-sort-${sortConfig.direction === 'asc' ? 'up' : 'down'}`}></i>
                )}
              </th>
              <th onClick={() => handleSort('marketCap')}>
                Market Cap
                {sortConfig.key === 'marketCap' && (
                  <i className={`fas fa-sort-${sortConfig.direction === 'asc' ? 'up' : 'down'}`}></i>
                )}
              </th>
              <th>7j Chart</th>
              <th>Indicateurs</th>
            </tr>
          </thead>
          <tbody>
            {getSortedResults().map(asset => (
              <tr key={asset.symbol}>
                <td className="symbol-cell">
                  <img src={asset.icon} alt={asset.symbol} />
                  <div>
                    <span className="symbol">{asset.symbol}</span>
                    <span className="name">{asset.name}</span>
                  </div>
                </td>
                <td>{formatNumber(asset.price, 'price')}</td>
                <td className={asset.change24h >= 0 ? 'positive' : 'negative'}>
                  {formatNumber(asset.change24h, 'percent')}
                </td>
                <td>{formatNumber(asset.volume, 'volume')}</td>
                <td>{formatNumber(asset.marketCap, 'marketCap')}</td>
                <td className="chart-cell">
                  {renderMiniChart(asset.priceHistory)}
                </td>
                <td className="indicators-cell">
                  <div className="indicator-badge" title="RSI">
                    {asset.indicators.rsi.toFixed(1)}
                  </div>
                  <div className={`indicator-badge ${asset.indicators.macd > 0 ? 'positive' : 'negative'}`} title="MACD">
                    {asset.indicators.macd > 0 ? 'Bull' : 'Bear'}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ScreenerResults; 
import React, { useState } from 'react';
import './TaskForm.css';

function TaskForm({ onAddTask }) {
  const [task, setTask] = useState({
    title: '',
    description: '',
    priority: 'medium',
    deadline: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onAddTask({
      ...task,
      id: Date.now().toString(),
    });
    setTask({
      title: '',
      description: '',
      priority: 'medium',
      deadline: '',
    });
  };

  return (
    <form className="task-form" onSubmit={handleSubmit}>
      <div className="form-row">
        <div className="form-group">
          <label>Titre</label>
          <input
            type="text"
            value={task.title}
            onChange={(e) => setTask({ ...task, title: e.target.value })}
            placeholder="Titre de la tâche"
            required
          />
        </div>

        <div className="form-group">
          <label>Priorité</label>
          <select
            value={task.priority}
            onChange={(e) => setTask({ ...task, priority: e.target.value })}
          >
            <option value="low">Basse</option>
            <option value="medium">Moyenne</option>
            <option value="high">Haute</option>
          </select>
        </div>
      </div>

      <div className="form-group">
        <label>Description</label>
        <textarea
          value={task.description}
          onChange={(e) => setTask({ ...task, description: e.target.value })}
          placeholder="Description de la tâche"
        />
      </div>

      <div className="form-group">
        <label>Date limite</label>
        <input
          type="date"
          value={task.deadline}
          onChange={(e) => setTask({ ...task, deadline: e.target.value })}
          required
        />
      </div>

      <button type="submit" className="submit-btn">
        Ajouter la tâche
      </button>
    </form>
  );
}

export default TaskForm; 
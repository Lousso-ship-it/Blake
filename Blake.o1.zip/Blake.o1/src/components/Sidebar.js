import React from 'react';
import { NavLink } from 'react-router-dom';
import './Sidebar.css';

function Sidebar() {
  return (
    <div className="sidebar">
      <div className="logo">
        <h1>Blake.o1</h1>
      </div>
      <nav>
        <NavLink to="/" end>
          Accueil
        </NavLink>
        <NavLink to="/workstation">
          Workstation
        </NavLink>
        <NavLink to="/datalake">
          Datalake
        </NavLink>
        <NavLink to="/dashboard">
          Dashboard
        </NavLink>
        <NavLink to="/finance">
          Finance
        </NavLink>
        <NavLink to="/planner">
          Planner
        </NavLink>
      </nav>
    </div>
  );
}

export default Sidebar; 
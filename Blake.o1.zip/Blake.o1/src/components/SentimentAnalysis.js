import React from 'react';
import './SentimentAnalysis.css';

function SentimentAnalysis() {
  const sentimentData = {
    overall: 65,
    indicators: [
      { name: 'Réseaux Sociaux', value: 72, trend: 'up' },
      { name: 'Analyse News', value: 58, trend: 'down' },
      { name: 'Volume', value: 63, trend: 'up' },
      { name: 'Volatilité', value: 45, trend: 'down' }
    ],
    signals: [
      {
        source: 'Twitter',
        sentiment: 'positive',
        message: 'Forte accumulation institutionnelle sur BTC',
        timestamp: '2 min ago'
      },
      {
        source: 'News',
        sentiment: 'negative',
        message: 'Régulation crypto en discussion',
        timestamp: '5 min ago'
      },
      // Plus de signaux...
    ]
  };

  return (
    <div className="sentiment-analysis">
      <div className="sentiment-header">
        <h3>Analyse du Sentiment</h3>
        <div className="overall-sentiment">
          <div className="sentiment-gauge">
            <svg viewBox="0 0 36 36">
              <path
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#2a2a2a"
                strokeWidth="3"
              />
              <path
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#26a69a"
                strokeWidth="3"
                strokeDasharray={`${sentimentData.overall}, 100`}
              />
            </svg>
            <div className="gauge-value">{sentimentData.overall}%</div>
          </div>
          <span className="gauge-label">Sentiment Global</span>
        </div>
      </div>

      <div className="sentiment-indicators">
        {sentimentData.indicators.map((indicator, index) => (
          <div key={index} className="indicator-item">
            <div className="indicator-header">
              <span>{indicator.name}</span>
              <span className={`trend ${indicator.trend}`}>
                <i className={`fas fa-arrow-${indicator.trend}`} />
              </span>
            </div>
            <div className="progress-bar">
              <div 
                className="progress"
                style={{ width: `${indicator.value}%` }}
              />
            </div>
            <span className="indicator-value">{indicator.value}%</span>
          </div>
        ))}
      </div>

      <div className="sentiment-signals">
        <h4>Signaux Récents</h4>
        <div className="signals-list">
          {sentimentData.signals.map((signal, index) => (
            <div key={index} className={`signal-item ${signal.sentiment}`}>
              <div className="signal-source">
                <i className={`fab fa-${signal.source.toLowerCase()}`} />
                {signal.source}
              </div>
              <div className="signal-message">{signal.message}</div>
              <div className="signal-time">{signal.timestamp}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default SentimentAnalysis; 
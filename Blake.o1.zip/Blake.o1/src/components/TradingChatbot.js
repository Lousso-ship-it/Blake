import React, { useState, useRef, useEffect } from 'react';
import { useMarketData } from '../hooks/useMarketData';
import './TradingChatbot.css';

function TradingChatbot() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      type: 'bot',
      content: 'Bonjour! Je suis votre assistant trading. Je peux vous aider avec l\'analyse technique, les signaux de trading et la gestion de risque. Comment puis-je vous aider aujourd\'hui?'
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  // Données en temps réel pour le contexte
  const btcData = useMarketData('binance', 'BTC/USD', 'ticker');
  const ethData = useMarketData('binance', 'ETH/USD', 'ticker');

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = {
      id: messages.length + 1,
      type: 'user',
      content: input
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      // Ajouter le contexte du marché à la requête
      const context = {
        btcPrice: btcData?.data?.close,
        ethPrice: ethData?.data?.close,
        timestamp: new Date().toISOString()
      };

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: input,
          context
        })
      });

      const data = await response.json();

      const botMessage = {
        id: messages.length + 2,
        type: 'bot',
        content: data.response
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Erreur chat:', error);
      const errorMessage = {
        id: messages.length + 2,
        type: 'bot',
        content: 'Désolé, une erreur est survenue. Veuillez réessayer.'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  return (
    <div className="trading-chatbot">
      <div className="chat-header">
        <h3>Assistant Trading</h3>
        <div className="market-context">
          <span className="price">
            BTC: ${btcData?.data?.close?.toFixed(2) || '---'}
          </span>
          <span className="price">
            ETH: ${ethData?.data?.close?.toFixed(2) || '---'}
          </span>
        </div>
      </div>

      <div className="chat-messages">
        {messages.map(message => (
          <div key={message.id} className={`message ${message.type}`}>
            <div className="message-content">
              {message.type === 'bot' && (
                <div className="avatar">
                  <i className="fas fa-robot"></i>
                </div>
              )}
              <div className="content">
                {message.content}
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="typing-indicator">
            <div className="dot"></div>
            <div className="dot"></div>
            <div className="dot"></div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <form className="chat-input" onSubmit={handleSubmit}>
        <textarea
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Posez votre question ici..."
          rows={1}
        />
        <button type="submit" disabled={!input.trim() || isTyping}>
          <i className="fas fa-paper-plane"></i>
        </button>
      </form>
    </div>
  );
}

export default TradingChatbot; 